package com.example.jikan.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.jikan.R
import com.example.jikan.data.AppDatabase
import com.example.jikan.data.PauseState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

object PauseManager {
    private const val CHANNEL_ID = "jikan_pause_channel"
    private const val NOTIFICATION_ID_LOCKING = 2001
    private const val NOTIFICATION_ID_RESUMED = 2002
    const val WORK_NAME = "pause_expiry_work"
    const val ACTION_TOGGLE = "com.example.jikan.ACTION_TOGGLE_PAUSE"
    const val ACTION_DISABLE_ACCESSIBILITY = "com.example.jikan.ACTION_DISABLE_ACCESSIBILITY"

    suspend fun getExpiry(context: Context): Long = withContext(Dispatchers.IO) {
        val db = AppDatabase.getInstance(context)
        db.pauseStateDao().get()?.expiryTimestampMs ?: 0L
    }

    suspend fun isPaused(context: Context): Boolean {
        val expiry = getExpiry(context)
        return PauseStatusCalculator.status(expiry, System.currentTimeMillis()).isPaused
    }

    suspend fun pause(context: Context, durationMinutes: Int = 10) = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val currentExpiry = getExpiry(context)
        val newExpiry = PauseStatusCalculator.nextExpiry(now, currentExpiry, durationMinutes)

        val db = AppDatabase.getInstance(context)
        db.pauseStateDao().upsert(PauseState(expiryTimestampMs = newExpiry))

        val delayMs = newExpiry - now
        val workRequest = OneTimeWorkRequestBuilder<PauseExpiryWorker>()
            .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            WORK_NAME,
            androidx.work.ExistingWorkPolicy.REPLACE,
            workRequest,
        )

        showToggleNotification(context, isPaused = true, expiryTimestampMs = newExpiry)
    }

    suspend fun resume(context: Context) = withContext(Dispatchers.IO) {
        val db = AppDatabase.getInstance(context)
        db.pauseStateDao().upsert(PauseState(expiryTimestampMs = 0L))

        WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)

        showToggleNotification(context, isPaused = false)
        showResumedNotification(context)
    }

    suspend fun handleExpiry(context: Context) = withContext(Dispatchers.IO) {
        val db = AppDatabase.getInstance(context)
        db.pauseStateDao().upsert(PauseState(expiryTimestampMs = 0L))

        showToggleNotification(context, isPaused = false)
        showResumedNotification(context)
    }

    suspend fun toggle(context: Context, durationMinutes: Int = 10) {
        if (isPaused(context)) {
            resume(context)
        } else {
            pause(context, durationMinutes)
        }
    }

    fun requestAccessibilityDisable(context: Context) {
        context.sendBroadcast(Intent(ACTION_DISABLE_ACCESSIBILITY).setPackage(context.packageName))
    }

    suspend fun prepareForAccessibilityDisable(context: Context) = withContext(Dispatchers.IO) {
        val db = AppDatabase.getInstance(context)
        db.pauseStateDao().upsert(PauseState(expiryTimestampMs = 0L))
        WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        cancelLockingNotification(context)
    }

    fun showToggleNotification(context: Context, isPaused: Boolean, expiryTimestampMs: Long = 0L) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createChannel(notificationManager)

        val toggleIntent = Intent(context, PauseReceiver::class.java).apply {
            action = ACTION_TOGGLE
        }
        val togglePendingIntent = PendingIntent.getBroadcast(
            context,
            0,
            toggleIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val title: String
        val text: String
        val actionLabel: String
        val status = PauseStatusCalculator.status(expiryTimestampMs, System.currentTimeMillis())
        if (isPaused && status.isPaused) {
            val remainingMinutes = status.remainingMinutes
            title = "Locking paused"
            text = "Resumes in ${remainingMinutes}m"
            actionLabel = "Banking mode"
        } else {
            title = "Locking active"
            text = "Use banking mode to temporarily disable Jikan in Accessibility."
            actionLabel = "Banking mode"
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .addAction(0, actionLabel, togglePendingIntent)
            .build()

        safeNotify(notificationManager, NOTIFICATION_ID_LOCKING, notification)
    }

    private fun showResumedNotification(context: Context) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createChannel(notificationManager)

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Locking resumed")
            .setContentText("App locking is active again.")
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

        safeNotify(notificationManager, NOTIFICATION_ID_RESUMED, notification)
    }

    private fun cancelLockingNotification(context: Context) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.cancel(NOTIFICATION_ID_LOCKING)
    }

    fun createReminderChannel(notificationManager: NotificationManager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "jikan_reminder_channel",
                "Jikan Reminders",
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "Shows gentle reminders for lightly restricted apps"
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun createChannel(notificationManager: NotificationManager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Jikan Locking",
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "Shows app locking status and pause controls"
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun safeNotify(
        notificationManager: NotificationManager,
        notificationId: Int,
        notification: android.app.Notification,
    ) {
        try {
            notificationManager.notify(notificationId, notification)
        } catch (exception: SecurityException) {
            Log.w(TAG, "Notification permission denied; pause state still updated", exception)
        }
    }

    private const val TAG = "JikanPause"
}
