package com.example.jikan.coach

import android.content.Context
import java.io.File

class ModelManager(private val context: Context) {
    private val modelDir: File
        get() = File(context.filesDir, "model")

    val modelFile: File
        get() = File(modelDir, MODEL_FILENAME)

    fun isModelAvailable(): Boolean {
        return modelFile.exists() && modelFile.length() > 0
    }

    fun getModelPath(): String {
        return modelFile.absolutePath
    }

    companion object {
        const val MODEL_FILENAME = "jikan-model.gguf"
    }
}
