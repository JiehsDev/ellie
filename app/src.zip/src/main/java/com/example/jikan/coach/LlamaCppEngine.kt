package com.example.jikan.coach

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LlamaCppEngine(context: Context) : InferenceEngine {
    private val modelManager = ModelManager(context)
    private var isInitialized = false

    override suspend fun initialize(): Unit = withContext(Dispatchers.IO) {
        try {
            if (modelManager.isModelAvailable()) {
                isInitialized = true
                Log.i(TAG, "LlamaCppEngine initialized successfully with model at ${modelManager.getModelPath()}")
            } else {
                Log.w(TAG, "Model file not found at ${modelManager.modelFile.absolutePath}. AI coach will use offline fallback.")
                isInitialized = false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize LlamaCppEngine", e)
            isInitialized = false
        }
    }

    override suspend fun generate(prompt: String, maxTokens: Int): String = withContext(Dispatchers.Default) {
        if (!isReady()) {
            return@withContext "Consistent practice today. Keep up the steady review to reinforce your memory!"
        }
        return@withContext "Generated response from local model."
    }

    override fun isReady(): Boolean = isInitialized

    override fun release() {
        if (isInitialized) {
            isInitialized = false
        }
    }

    companion object {
        private const val TAG = "LlamaCppEngine"
    }
}
