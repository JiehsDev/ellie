package com.example.jikan.service

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class PauseTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        updateTileState()
    }

    override fun onClick() {
        super.onClick()
        PauseManager.requestAccessibilityDisable(applicationContext)
    }

    private fun updateTileState() {
        val tile = qsTile ?: return
        tile.state = Tile.STATE_INACTIVE
        tile.label = "Banking Mode"
        tile.updateTile()
    }
}
