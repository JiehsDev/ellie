package com.example.jikan.ui.coach

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.jikan.R
import com.example.jikan.ui.theme.JikanTheme
import com.example.jikan.ui.theme.NeoCard
import com.example.jikan.ui.theme.RadiusSm

@Composable
fun JikanCoachMessage(
    message: String,
    modifier: Modifier = Modifier,
) {
    NeoCard(modifier = modifier.fillMaxWidth(), elevation = 6.dp) {
        Row(verticalAlignment = Alignment.Top) {
            Image(
                painter = painterResource(R.drawable.mascot_jikan_coach),
                contentDescription = "Jikan Coach",
                modifier = Modifier
                    .size(58.dp)
                    .clip(RoundedCornerShape(RadiusSm))
                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(RadiusSm))
                    .padding(6.dp),
            )
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Jikan Coach",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = "Generated locally · Offline",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun JikanCoachMessagePreview() {
    JikanTheme {
        JikanCoachMessage(
            message = "Steady work today. Your accuracy was solid, and the missed cards are ready for a gentle review next time.",
            modifier = Modifier.padding(24.dp),
        )
    }
}
